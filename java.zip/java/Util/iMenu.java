package Util;

public interface iMenu {
    void menu();
}
